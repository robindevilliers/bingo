var profile = 
{
    "description":"Bingo performance test.",
    "executionTime":1458202773980,
    "durationInSeconds":1199,
    "bulletPoints":[
        "1000 users",
        "mongo locking",
        "memory based chat",
        "mongo all collections, fsynced persistence"
    ]
}