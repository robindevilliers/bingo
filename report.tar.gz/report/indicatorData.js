var indicatorData = 
[
    [
        "t < 800ms",
        2895555
    ],
    [
        "800ms < t < 1200ms",
        2071
    ],
    [
        "1200ms < t",
        2258
    ]
]