var requestTypesData = 
[
    {
        "name":" ENTER_LOBBY",
        "y":1000
    },
    {
        "name":" POLL_STATE",
        "y":692334
    },
    {
        "name":" ANTE_IN",
        "y":2685
    },
    {
        "name":" SEND_CHAT_MESSAGE",
        "y":80171
    },
    {
        "name":" TOP_UP",
        "y":1000
    },
    {
        "name":" POLL_CHAT_MESSAGES",
        "y":2120694
    },
    {
        "name":" REGISTER",
        "y":1000
    },
    {
        "name":" JOIN_PLAY",
        "y":1000
    }
]